#!/bin/bash
echo "Content-type: text/html"
echo ""
if [ "$REQUEST_METHOD" != "GET" ]; then
    echo "<hr>Script Error:"\
        "<br>Usage error, cannot complete request, REQUEST_METHOD!=GET."\
        "<br>Check your FORM declaration and be sure to use METHOD=\"GET\".<hr>"
    exit 1
fi
if [ -z "$QUERY_STRING" ]; then
    exit 0
else
urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }
# IPADD=`echo "$QUERY_STRING" | sed -n 's/^.*IP=\([^&]*\).*$/\1/p' | sed "s/%20/ /g"`
FILES=`echo "$QUERY_STRING" | sed -n 's/^.*FS=\([^&]*\).*$/\1/p' | sed "s/%20/ /g"|awk -F'\' '{print $NF}'`

time=`date "+%Y-%m-%d %H:%M:%S"`

cd /tmp/
filemd5=`sudo md5sum /tmp/$FILES| awk '{print$1}'`
filesize=`sudo du -sh /tmp/$FILES |awk '{print$1}'`


[ -f /tmp/$FILES ] && echo "$time $FILES 上传成功! 文件大小为:$filesize  md5值为:$filemd5" >> /var/www/html/logs/apk_upload.log;echo "$time $FILES uploaded successfully! file size:$filesize  md5:$filemd5" || echo $FILES uploaded filed!!


fi
exit 0
