#!/bin/bash
echo "Content-type: text/html"
echo ""
if [ "$REQUEST_METHOD" != "GET" ]; then
    echo "<hr>Script Error:"\
        "<br>Usage error, cannot complete request, REQUEST_METHOD!=GET."\
        "<br>Check your FORM declaration and be sure to use METHOD=\"GET\".<hr>"
    exit 1
fi
if [ -z "$QUERY_STRING" ]; then
    exit 0
else
urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }
# IPADD=`echo "$QUERY_STRING" | sed -n 's/^.*IP=\([^&]*\).*$/\1/p' | sed "s/%20/ /g"`
FILES=`echo "$QUERY_STRING" | sed -n 's/^.*FS=\([^&]*\).*$/\1/p' | sed "s/%20/ /g"|awk -F'\' '{print $NF}'`
EV=`echo "$QUERY_STRING" | sed -n 's/^.*FS=\([^&]*\).*$/\1/p' | sed "s/%20/ /g"|awk -F'\' '{print $NF}' | awk -F '_' '{print $2$3}'`
VER=`echo "$QUERY_STRING" | sed -n 's/^.*FS=\([^&]*\).*$/\1/p' | sed "s/%20/ /g"|awk -F'\' '{print $NF}' |awk -F '_' '{print $1}'|sed "s/yjb//g"`

time=`date "+%Y-%m-%d %H:%M:%S"`

cd /tmp/
sudo chown -R root:root /tmp/$FILES
sudo chmod -R 777 $FILES

if [ fzrelease == $EV ];then
    FPATH=sim-android
    else
    if [ sprelease == $EV ];then
        FPATH=rea-android
        else
        if [ screlease == $EV ];then
            FPATH=pro-android
            else
            if [ csrelease == $EV ];then
                FPATH=test-android
                else
                if [ h5devrelease == $EV ];then
                    FPATH=dev-android
                    else
                        FPATH=debug-android
                    fi
                fi
            fi
        fi
    fi
fi

sudo ssh -p 9999 192.168.24.73 "mkdir /home/yjb/app/download/$FPATH/$VER/"
sudo scp -P 9999 /tmp/$FILES 192.168.24.73:/home/yjb/app/download/$FPATH/$VER


#check
status=`curl -s "http://192.168.24.73/app/index.php"|grep $FILES|wc -l `
if [ 1 == $status ];then
    echo "$FILES copy 192.168.24.73 path:/home/yjb/app/download/$FPATH/ successfully!"
    echo "$time $FILES 上传成功!上传路径192.168.24.73:/home/yjb/app/download/$FPATH/ " >> /var/www/html/logs/apk_upload.log
    else
    echo "$FILES copy failed！"
fi

sudo rm -rf /tmp/*.apk

fi
exit 0
